create database courier


CREATE TABLE `address`
  (
 
  `street` varchar(45) NOT NULL,
  
  `sublocation` varchar(45) DEFAULT NULL,

  `city` varchar(45) DEFAULT NULL,

  `state` varchar(45) DEFAULT NULL,

  `country` varchar(45) DEFAULT NULL,
  
  `pincode` varchar(45) DEFAULT NULL,
  
  `userId` varchar(45) NOT NULL,
  
  PRIMARY KEY (`userId`)

  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `items` 
  (
  
  `itemName` varchar(45) NOT NULL,
 
  `categoryId` varchar(45) DEFAULT NULL,
 
  `yearsOfUsage` varchar(45) DEFAULT NULL,
 
  `itemId` varchar(45) DEFAULT NULL,
  
  `itemImage` longblob,
  
  `userId` varchar(45) NOT NULL,
 
  `price` varchar(45) DEFAULT NULL,
  
  PRIMARY KEY (`itemName`,`userId`)
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE `user`
  (
 
  `firstName` varchar(45) NOT NULL,
  
  `lastname` varchar(45) NOT NULL,
  
  `dateOfBirth` varchar(45) NOT NULL,
  
  `gender` varchar(45) NOT NULL,
  
  `contactNumber` varchar(45) NOT NULL,
  
  `userId` varchar(45) NOT NULL,
  
  `password` varchar(45) DEFAULT NULL,
  
  `email` varchar(45) DEFAULT NULL,
  
  `address` varchar(45) DEFAULT NULL,
  
  PRIMARY KEY (`userId`),
  
  UNIQUE KEY `email_UNIQUE` (`email`)

  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

